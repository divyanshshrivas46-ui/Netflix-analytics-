SELECT type, COUNT(*) AS total_titles
FROM netflix_powerbi_large_dataset
GROUP BY type;